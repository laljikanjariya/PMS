//
//  UserSignUpVC.swift
//  ProjectManagmentSystem
//
//  Created by Siya9 on 30/11/16.
//  Copyright © 2016 Siya9. All rights reserved.
//

import UIKit

class UserSignUpVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
