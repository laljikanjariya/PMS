//
//  ProjectDetailVC.swift
//  ProjectManagmentSystem
//
//  Created by Siya9 on 29/11/16.
//  Copyright © 2016 Siya9. All rights reserved.
//

import UIKit
import CoreData

class ProjectDetailVC: UIViewController {
    @IBOutlet var txtPName : UITextField?
    var objProject : Project!
    var objMOC : NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtPName?.text = self.objProject.pName
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func saveProject(sender:UIButton){
        objProject.pName = txtPName?.text
        
        DBUpdateManager.saveContext(parentMOC: objMOC)
        _ = navigationController?.popViewController(animated: true)
    }
}
