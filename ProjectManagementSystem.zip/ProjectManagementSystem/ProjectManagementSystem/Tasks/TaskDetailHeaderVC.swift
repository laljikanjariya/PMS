//
//  TaskDetailHeaderVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 14/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit

class TaskDetailImagesListCell: UICollectionViewCell {
    
    @IBOutlet weak var btnChangeImage: UIButton!
    @IBOutlet private weak var imgVSelected: UIImageView!
    
    var imageSelected:UIImage? {
        get {
            return imgVSelected.image
        }
        set(imageSelected) {
            imgVSelected.image = imageSelected
        }
    }
    
}

class TaskDetailHeaderVC: UIViewController , UITextFieldDelegate, UITextViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var txtTaskTitle: UITextField!
    @IBOutlet weak var txtVTaskDescription: UITextView!
    @IBOutlet weak var collImagesList: UICollectionView!
    
    private var imagePicker = UIImagePickerController()
    private var updateImage: Image!
    
    var objTask : Task!
    private var imageList = [Any]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.updateImageList()
        self.updateTaskDetail()
    }
    func updateTaskDetail() {
        txtTaskTitle.text = objTask.name
        txtVTaskDescription.text = objTask.task_desc
        collImagesList.reloadData()
    }
    func updateImageList() {
        if (objTask.images?.allObjects.count)! > 0 {
            imageList = (objTask.images?.allObjects)!
            if (imageList.count) < 10 {
                imageList.append("Add New")
            }
        }
        else {
            imageList = []
            imageList.append("Add New")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK:- ---> Actions -
    @IBAction func btnRemoveImage(_ sender: UIButton) {
        let image:Image = imageList[sender.tag] as! Image
        imageList.remove(at: sender.tag)
        objTask?.removeFromImages(image)
        image.project = nil
        self.updateTaskDetail()
    }
    // MARK:- ---> Textfield Delegates -
    func textFieldDidEndEditing(_ textField: UITextField) {
        objTask.name = textField.text
        objTask.updatedAt = Date()
        self.updateTaskDetail()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        return true;
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        objTask.task_desc = textView.text
        objTask.updatedAt = Date()
        self.updateTaskDetail()
    }
    // MARK:- ---> CollectionView Delegates -
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! TaskDetailImagesListCell
        let image:Image? = imageList[indexPath.row] as? Image
        cell.btnChangeImage.tag = indexPath.row;
        if (image != nil) {
            cell.imageSelected =  UIImage(data: (image?.imageData!)!)
            cell.btnChangeImage.isHidden = false
        }
        else {
            cell.imageSelected =  UIImage(imageLiteralResourceName: "add_Project_Images")
            cell.btnChangeImage.isHidden = true
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        updateImage = imageList[indexPath.row] as? Image
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! TaskDetailImagesListCell
            alert.popoverPresentationController?.sourceView = cell
            alert.popoverPresentationController?.sourceRect = cell.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)) {
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary() {
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        //        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info:[String : Any]) {
        let tempImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        let data = UIImagePNGRepresentation(tempImage) as Data?
        if updateImage != nil {
            updateImage.imageData = data
        }
        else {
            let image:Image = DBUpdateManager.insertObject(entityName: "Image", moc: objTask.managedObjectContext!) as! Image
            image.imageData = data
            image.task = objTask
            objTask.addToImages(image)
            self.updateImageList()
        }
        collImagesList.reloadData()
        self.view.layoutSubviews()
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}
