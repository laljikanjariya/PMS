//
//  TaskListVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 14/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit
import CoreData

class TaskListCell: UITableViewCell {
    @IBOutlet var lblTName : UILabel?
    @IBOutlet var lblTime : UILabel?
    func configureWithTask(taskInfo : Task)  {
        self.lblTName?.text = taskInfo.name
        self.lblTime?.text = UtilityManager.getDurationFrom(fromDate: taskInfo.createdAt!, toDate: Date())
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}


class TaskListVC: UIViewController ,NSFetchedResultsControllerDelegate , UITableViewDelegate ,UITableViewDataSource {

    @IBOutlet weak var tblTaskList: UITableView!
    var managedObjectContext:NSManagedObjectContext = DatabaseManager.sharedInstance().persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnNewAddTask(_ sender: UIButton) {
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
        let objTask:Task = DBUpdateManager.insertObject(entityName: "Task", moc: moc) as! Task
        self.showTaskDetailVC(objTask: objTask, moc: moc)
    }
    
    internal func numberOfSections(in tableView: UITableView) -> Int {
        if let sections = taskListRC.sections {
            return sections.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = taskListRC.sections {
            let sectionInfo = sections[section]
            return sectionInfo.numberOfObjects
        }
        return 0
    }
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell : TaskListCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TaskListCell
        let taskInfo : Task = taskListRC.object(at: indexPath) as! Task
        cell.configureWithTask(taskInfo:taskInfo)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
        let objTask:Task = taskListRC.object(at: indexPath) as! Task
        self.showTaskDetailVC(objTask: moc.object(with: objTask.objectID) as! Task, moc: moc)
    }
    
    internal func tableView(_ tableView: UITableView, canFocusRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
            let objProject :Project = self.taskListRC.object(at: indexPath as IndexPath) as! Project
            let objEditProject = moc.object(with: objProject.objectID) as! Project
            moc.delete(objEditProject)
            DBUpdateManager.saveContext(parentMOC: moc)
        }
    }
    
    func showTaskDetailVC(objTask : Task , moc:NSManagedObjectContext){
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let taskDetailVC : TaskDetailVC = storyBoard.instantiateViewController(withIdentifier: "TaskDetailVC_sid") as! TaskDetailVC
        taskDetailVC.objTask = objTask
        taskDetailVC.privateMOC = moc
        self.navigationController?.pushViewController(taskDetailVC, animated: true)
    }
    //MARK: - CoreData -
    lazy var taskListRC: NSFetchedResultsController<NSFetchRequestResult> = {
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Task")
        // Add Sort Descriptors
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        // Initialize Fetched Results Controller
        let fetchedResultsController = NSFetchedResultsController.init(fetchRequest: fetchRequest, managedObjectContext: self.managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("An error occurred")
        }
        // Configure Fetched Results Controller
        fetchedResultsController.delegate = self
        
        return fetchedResultsController
    }()
    
    private func controllerWillChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblTaskList?.beginUpdates()
    }
    
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch (type) {
        case .insert:
            if let indexPath = newIndexPath {
                self.tblTaskList?.insertRows(at: [indexPath], with: .fade)
            }
            break;
        case .delete:
            if let indexPath = indexPath {
                self.tblTaskList?.deleteRows(at: [indexPath], with: .fade)
            }
            break;
        case .update:
            if (self.tblTaskList?.indexPathsForVisibleRows?.contains(indexPath!))! {
                self.tblTaskList?.reloadRows(at: [indexPath!], with: .fade)
            }
            break;
        case .move:
            if let indexPath = indexPath {
                self.tblTaskList?.deleteRows(at: [indexPath], with: .fade)
            }
            
            if let newIndexPath = newIndexPath {
                self.tblTaskList?.insertRows(at: [newIndexPath], with: .fade)
            }
            break;
        }
    }
    private func controllerDidChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblTaskList?.endUpdates()
    }
}
