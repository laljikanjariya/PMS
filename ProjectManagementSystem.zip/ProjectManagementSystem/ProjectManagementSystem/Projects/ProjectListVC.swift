//
//  ProjectListVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 11/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit
import CoreData

class ProjectListCell: UITableViewCell {
    @IBOutlet var lblPName : UILabel?
    @IBOutlet var lblTime : UILabel?
    func configureWithProject(projectInfo : Project)  {
        self.lblPName?.text = projectInfo.name
        self.lblTime?.text = UtilityManager.getDurationFrom(fromDate: projectInfo.createdAt!, toDate: Date())
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}

class ProjectListVC: UIViewController ,NSFetchedResultsControllerDelegate , UITableViewDelegate ,UITableViewDataSource {
    
    @IBOutlet weak var tblProjectList: UITableView!
    var managedObjectContext:NSManagedObjectContext = DatabaseManager.sharedInstance().persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.managedObjectContext = DatabaseManager.sharedInstance().persistentContainer.viewContext
        self.navigationController?.isNavigationBarHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnNewAddProject(_ sender: UIButton) {
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
        let objProject:Project = DBUpdateManager.insertObject(entityName: "Project", moc: moc) as! Project
        self.showProjectDetailVC(objProject: objProject, moc: moc)
    }
    
    internal func numberOfSections(in tableView: UITableView) -> Int {
        if let sections = projectListRC.sections {
            return sections.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = projectListRC.sections {
            let sectionInfo = sections[section]
            return sectionInfo.numberOfObjects
        }
        return 0
    }
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell : ProjectListCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ProjectListCell
        let projectInfo : Project = projectListRC.object(at: indexPath) as! Project
        cell.configureWithProject(projectInfo:projectInfo)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
        let objProject:Project = projectListRC.object(at: indexPath) as! Project
        self.showProjectDetailVC(objProject: moc.object(with: objProject.objectID) as! Project, moc: moc)
    }
    
    internal func tableView(_ tableView: UITableView, canFocusRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
            let objProject :Project = self.projectListRC.object(at: indexPath as IndexPath) as! Project
            let objEditProject = moc.object(with: objProject.objectID) as! Project
            moc.delete(objEditProject)
            DBUpdateManager.saveContext(parentMOC: moc)
        }
    }
    
    func showProjectDetailVC(objProject : Project , moc:NSManagedObjectContext){
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let projectDetailVC : ProjectDetailVC = storyBoard.instantiateViewController(withIdentifier: "ProjectDetailVC_sid") as! ProjectDetailVC
        projectDetailVC.objProject = objProject
        projectDetailVC.privateMOC = moc
        self.navigationController?.pushViewController(projectDetailVC, animated: true)
    }
    //MARK: - CoreData -
    lazy var projectListRC: NSFetchedResultsController<NSFetchRequestResult> = {
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Project")
        // Add Sort Descriptors
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        // Initialize Fetched Results Controller
        let fetchedResultsController = NSFetchedResultsController.init(fetchRequest: fetchRequest, managedObjectContext: self.managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("An error occurred")
        }
        // Configure Fetched Results Controller
        fetchedResultsController.delegate = self
        
        return fetchedResultsController
    }()
    
    private func controllerWillChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblProjectList?.beginUpdates()
    }
    
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch (type) {
        case .insert:
            if let indexPath = newIndexPath {
                self.tblProjectList?.insertRows(at: [indexPath], with: .fade)
            }
            break;
        case .delete:
            if let indexPath = indexPath {
                self.tblProjectList?.deleteRows(at: [indexPath], with: .fade)
            }
            break;
        case .update:
            if (self.tblProjectList?.indexPathsForVisibleRows?.contains(indexPath!))! {
                self.tblProjectList?.reloadRows(at: [indexPath!], with: .fade)
            }
            break;
        case .move:
            if let indexPath = indexPath {
                self.tblProjectList?.deleteRows(at: [indexPath], with: .fade)
            }
            
            if let newIndexPath = newIndexPath {
                self.tblProjectList?.insertRows(at: [newIndexPath], with: .fade)
            }
            break;
        }
    }
    private func controllerDidChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblProjectList?.endUpdates()
    }
}
