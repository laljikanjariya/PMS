//
//  ProjectDetailVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 11/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit
import CoreData

class ProjectDetailVC: UIViewController ,NSFetchedResultsControllerDelegate , UITableViewDelegate ,UITableViewDataSource, UINavigationControllerDelegate {

    @IBOutlet var tblTaskList : UITableView?
    var projectDetailHeaderVC: ProjectDetailHeaderVC!
    var objProject : Project!
    var privateMOC : NSManagedObjectContext!
    var managedObjectContext:NSManagedObjectContext = DatabaseManager.sharedInstance().persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    internal func numberOfSections(in tableView: UITableView) -> Int {
        if let sections = taskListRC.sections {
            return sections.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if projectDetailHeaderVC == nil {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            projectDetailHeaderVC = storyBoard.instantiateViewController(withIdentifier: "ProjectDetailHeaderVC_sid") as? ProjectDetailHeaderVC
            projectDetailHeaderVC.objProject = self.objProject
            self.addChildViewController(projectDetailHeaderVC)
        }
        return projectDetailHeaderVC?.view
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = taskListRC.sections {
            let sectionInfo = sections[section]
            return sectionInfo.numberOfObjects
        }
        return 0
    }
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//        cell.configureWithProject(projectInfo:projectInfo)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
//        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.managedObjectContext)
//        let objProject:Project = taskListRC.object(at: indexPath) as! Project
//        self.showProjectDetailVC(objProject: moc.object(with: objProject.objectID) as! Project, moc: moc)
    }
    
    internal func tableView(_ tableView: UITableView, canFocusRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.privateMOC)
            let objTask :Task = taskListRC.object(at: indexPath as IndexPath) as! Task
            let objEditTask = moc.object(with: objTask.objectID) as! Task
            moc.delete(objEditTask)
            DBUpdateManager.saveContext(parentMOC: moc)
        }
    }
    
//    func showProjectDetailVC(objProject : Project , moc:NSManagedObjectContext){
//        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//        let projectDetailVC : ProjectDetailVC = storyBoard.instantiateViewController(withIdentifier: "ProjectDetailVC_sid") as! ProjectDetailVC
//        projectDetailVC.objProject = objProject
//        projectDetailVC.managedObjectContext = moc
//        self.navigationController?.pushViewController(projectDetailVC, animated: true)
//    }
    //MARK: - CoreData -
    
    
    @IBAction func btnAddTask(_ sender: UIButton) {
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.privateMOC)
        let objTask:Task = DBUpdateManager.insertObject(entityName: "Task", moc: moc) as! Task
        let privateProject:Project = moc.object(with: self.objProject.objectID) as! Project
        privateProject.addToTasks(objTask)
        objTask.project = privateProject
        self.showTaskDetailVC(objTask: objTask, moc: moc)
    }
    @IBAction func btnSaveProject(_ sender: UIButton) {
        self.view.endEditing(true)
        if privateMOC.hasChanges {
            DBUpdateManager.saveContext(parentMOC: privateMOC)
        }
        self.navigationController?.popViewController(animated: true)
    }
    func showTaskDetailVC(objTask : Task , moc:NSManagedObjectContext){
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let taskDetailVC : TaskDetailVC = storyBoard.instantiateViewController(withIdentifier: "TaskDetailVC_sid") as! TaskDetailVC
        taskDetailVC.objTask = objTask
        taskDetailVC.privateMOC = moc
        self.navigationController?.pushViewController(taskDetailVC, animated: true)
    }
    lazy var taskListRC: NSFetchedResultsController<NSFetchRequestResult> = {
        // Initialize Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Task")
        // Add Sort Descriptors
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        // Initialize Fetched Results Controller
        let fetchedResultsController = NSFetchedResultsController.init(fetchRequest: fetchRequest, managedObjectContext: self.privateMOC, sectionNameKeyPath: nil, cacheName: nil)
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("An error occurred")
        }
        // Configure Fetched Results Controller
        fetchedResultsController.delegate = self
        
        return fetchedResultsController
    }()
    
    private func controllerWillChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblTaskList?.beginUpdates()
    }
    
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch (type) {
        case .insert:
            if let indexPath = newIndexPath {
                self.tblTaskList?.insertRows(at: [indexPath], with: .fade)
            }
            break;
        case .delete:
            if let indexPath = indexPath {
                self.tblTaskList?.deleteRows(at: [indexPath], with: .fade)
            }
            break;
        case .update:
            if (self.tblTaskList?.indexPathsForVisibleRows?.contains(indexPath!))! {
                self.tblTaskList?.reloadRows(at: [indexPath!], with: .fade)
            }
            break;
        case .move:
            if let indexPath = indexPath {
                self.tblTaskList?.deleteRows(at: [indexPath], with: .fade)
            }
            
            if let newIndexPath = newIndexPath {
                self.tblTaskList?.insertRows(at: [newIndexPath], with: .fade)
            }
            break;
        }
    }
    private func controllerDidChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tblTaskList?.endUpdates()
    }
}
