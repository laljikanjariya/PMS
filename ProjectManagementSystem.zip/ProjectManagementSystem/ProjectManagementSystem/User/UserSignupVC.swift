//
//  UserSignupVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 11/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit
import CoreData
class UserSignupVC: UIViewController {
    var moc: NSManagedObjectContext?
    var user:User?
    override func viewDidLoad() {
        super.viewDidLoad()
        if moc == nil {
            moc = DBUpdateManager.createPrivateMOC(parentMOC: DatabaseManager.sharedInstance().persistentContainer.viewContext)
        }
        if user == nil {
            user = DBUpdateManager.insertObject(entityName: "User", moc: moc!) as? User
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
