//
//  UserLoginVC.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 11/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit

class UserLoginVC: UIViewController {
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtUserPassword: UITextField!
    @IBOutlet weak var btnSignIn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtUserName.text = "Admin"
        txtUserPassword.text = "Admin"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnSignInTapped(_ sender: UIButton) {
        let predicate:NSPredicate = NSPredicate.init(format: "userName == %@ && password == %@", txtUserName.text!, txtUserPassword.text!)
        let loginUser:User? = DBUpdateManager.fetchEntityWith(entityName: "User", predicate: predicate, moc: DatabaseManager.sharedInstance().persistentContainer.viewContext)?.first as? User
        if loginUser != nil {
            DatabaseManager.sharedInstance().logedUser = loginUser
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "PMSTabVC")
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        print("TextField should begin editing method called")
        return true;
    }
    
    func textFieldShouldClear(textField: UITextField) -> Bool {
        btnSignIn.isEnabled = false
        return true;
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        btnSignIn.isEnabled = ((txtUserName.text?.count)! > 0 && (txtUserPassword.text?.count)! > 0)
        return true;
    }
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField == txtUserName {
                btnSignIn.isEnabled = (txtAfterUpdate.count > 0 && (txtUserPassword.text?.count)! > 0)
            }
            else if textField == txtUserPassword {
                btnSignIn.isEnabled = ((txtUserName.text?.count)! > 0 && txtAfterUpdate.count > 0)
            }
        }
        return true;
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        return true;
    }
}
