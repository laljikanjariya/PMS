//
//  DatabaseManager.swift
//  ProjectManagementSystem
//
//  Created by Lalji on 11/05/18.
//  Copyright © 2018 Lalji. All rights reserved.
//

import UIKit
import CoreData

class DatabaseManager: NSObject {
    var logedUser:User?
    class func sharedInstance()-> DatabaseManager {
        struct Static {
            static let instance: DatabaseManager = DatabaseManager()
        }
        return Static.instance
    }
    override init() {
        super.init()
        self.setUpFirstTimeConfiguration()
    }
    // MARK: - Core Data stack
    func setUpFirstTimeConfiguration() {
        self.setAdminUserInDB()
    }
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "ProjectManagementSystem")
        
        let description = NSPersistentStoreDescription()
        
        description.shouldInferMappingModelAutomatically = true
        description.shouldMigrateStoreAutomatically = true
        
        container.persistentStoreDescriptions = [description]
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func setAdminUserInDB() {
        let moc:NSManagedObjectContext = DBUpdateManager.createPrivateMOC(parentMOC: self.persistentContainer.viewContext)
        let admin:User? = DBUpdateManager.fetchEntityWith(entityName: "User", keyValues: ["uID" : 1 as AnyObject], moc: moc, isCreate:true) as? User
        if admin?.role == nil {
            self.insertRoleInDB(moc: moc)
            let adminRole:UserRole? = DBUpdateManager.fetchEntityWith(entityName: "UserRole", keyValues: ["uID" : 1 as AnyObject], moc: moc, isCreate:true) as? UserRole
            admin?.role = adminRole;
            adminRole?.addToUsers(admin!)
            
            admin?.name = "Admin User"
            admin?.userName = "Admin"
            admin?.password = "Admin"
        }
        DBUpdateManager.save(parentMOC: moc)
    }
    func insertRoleInDB(moc:NSManagedObjectContext) {
        let roleList:[String] = ["Admin","PM","Developer","Tester","Clint"]
        
        for roleName:String in roleList {
            let userRole:UserRole? = DBUpdateManager.fetchEntityWith(entityName: "UserRole", keyValues: ["name" : roleName as AnyObject], moc: moc, isCreate:true) as? UserRole
            userRole?.name = roleName
        }
    }
}
