//
//  MessageLisner.swift
//  ProjectManagmentSystem
//
//  Created by Siya9 on 01/12/16.
//  Copyright © 2016 Siya9. All rights reserved.
//

import UIKit

class MessageLisner: NSObject {

}
